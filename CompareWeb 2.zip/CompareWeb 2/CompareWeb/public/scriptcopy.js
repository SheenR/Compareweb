function filterResults() {
    const brand = document.getElementById("brand").value.toLowerCase();
    const priceRange = document.getElementById("price-range").value;
    const screenSize = document.getElementById("screen-size").value;
    const ram = document.getElementById("ram").value;
    const batteryLife = document.getElementById("battery-life").value;
    const processor = document.getElementById("processor").value;
    const storage = document.getElementById("storage").value;
    const os = document.getElementById("os").value;

    const productCards = document.querySelectorAll(".product-card");
    let visibleCount = 0;

    productCards.forEach(card => {
        const cardBrand = card.dataset.brand.toLowerCase();
        const cardPrice = parseInt(card.dataset.price);
        const cardScreen = card.dataset.screen;
        const cardRam = card.dataset.ram;
        const cardBattery = parseInt(card.dataset.battery);
        const cardProcessor = card.dataset.processor;
        const cardStorage = card.dataset.storage;
        const cardOs = card.dataset.os;

        let showCard = true;

        // Apply brand filter
        if (brand !== "all" && cardBrand !== brand) showCard = false;

        // Apply price range filter
        if (priceRange !== "all") {
            const [min, max] = priceRange.split("-").map(Number);
            if (cardPrice < min || cardPrice > max) showCard = false;
        }

        // Apply screen size filter
        if (screenSize !== "all" && cardScreen !== screenSize) showCard = false;

        // Apply RAM filter
        if (ram !== "all" && cardRam !== ram) showCard = false;

        // Apply battery life filter
        if (batteryLife !== "all") {
            if (cardBattery <= 5 && batteryLife !== "5") showCard = false;
            else if (cardBattery > 5 && cardBattery <= 10 && batteryLife !== "10") showCard = false;
            else if (cardBattery > 10 && batteryLife !== "15") showCard = false;
        }

        // Apply processor filter
        if (processor !== "all" && cardProcessor !== processor) showCard = false;

        // Apply storage filter
        if (storage !== "all" && cardStorage !== storage) showCard = false;

        // Apply OS filter
        if (os !== "all" && cardOs !== os) showCard = false;

        // Show or hide the card based on filters
        card.style.display = showCard ? "block" : "none";

        // Count visible products
        if (showCard) visibleCount++;
    });

    // Handle "No Results" message
    const resultsContainer = document.getElementById("results");
    let noResultsMessage = document.querySelector(".no-results");

    if (visibleCount === 0) {
        if (!noResultsMessage) {
            noResultsMessage = document.createElement("div");
            noResultsMessage.className = "no-results";
            noResultsMessage.textContent = "No products match your filters. Try adjusting the filters.";
            resultsContainer.appendChild(noResultsMessage);
        }
    } else {
        if (noResultsMessage) noResultsMessage.remove();
    }
}
