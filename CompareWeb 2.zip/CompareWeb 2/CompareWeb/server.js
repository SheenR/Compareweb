const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');  // For handling CORS issues in local development
const app = express();
const port = 3000;

// Your eBay OAuth credentials
let clientId = ''; // eBay client ID
let clientSecret = ''; // eBay client secret
let accessToken = '';  // Access token for eBay API
let tokenExpirationTime = null;  // Time when the token expires

// Enable CORS for local development
app.use(cors());

// Serve static files from the current directory (for HTML, CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to handle JSON
app.use(express.json());

// Root route for basic information or test
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'compareweb.html'));  // Serve the home page
});

// Function to get eBay API access token (OAuth2)
async function getEbayAccessToken() {
  try {
    console.log("Requesting eBay access token...");
    
    // Create the authorization header
    const authorizationHeader = 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64');
    
    // Request the access token from eBay's OAuth endpoint
    const response = await axios.post('https://api.sandbox.ebay.com/identity/v1/oauth2/token', new URLSearchParams({
      'grant_type': 'client_credentials',
      'scope': 'https://api.ebay.com/oauth/api_scope'
    }).toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': authorizationHeader
      }
    });

    // Set the access token and expiration time
    accessToken = response.data.access_token;
    tokenExpirationTime = Date.now() + (response.data.expires_in * 1000);  // Set token expiration time

    console.log("Access Token: ", accessToken);
    console.log("Token expires at: ", new Date(tokenExpirationTime));
  } catch (error) {
    console.error("Error fetching access token:", error.response ? error.response.data : error.message);
    throw new Error("Failed to obtain access token");
  }
}

// Function to check if the access token is expired
function isAccessTokenExpired() {
  return Date.now() >= tokenExpirationTime;
}

// Function to fetch search results from eBay
async function fetchEbayListings(query) {
  try {
    // If the token is expired or doesn't exist, fetch a new one
    if (!accessToken || isAccessTokenExpired()) {
      await getEbayAccessToken();  // Refresh the token if expired
    }

    // Construct the search URL with the query
    const searchUrl = `https://api.sandbox.ebay.com/buy/browse/v1/item_summary/search?q=${query}`;

    console.log("Requesting URL:", searchUrl);  // Log the full request URL

    // Send the request to eBay's API with the access token
    const response = await axios.get(searchUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,  // Include the access token here
        'Content-Type': 'application/json'
      }
    });

    console.log('eBay API response:', response.data);

    // Check if data exists and format it correctly
    if (response.data && response.data.itemSummaries) {
      if (response.data.total > 0) {
        return response.data.itemSummaries.map(item => ({
          name: item.title,
          price: item.price.value,
          link: item.itemWebUrl,
          image: item.image ? item.image.imageUrl : 'No image available'
        }));
      } else {
        console.log('No items found for the search term.');
        return [];
      }
    } else {
      console.log('No item summaries found.');
      return [];
    }
  } catch (error) {
    console.error("Error fetching eBay listings: ", error.response ? error.response.data : error.message);
    // Send a response to the client if there's an error
    return { success: false, message: "Failed to fetch results." };
  }
}

// Route for search
app.get('/search', async (req, res) => {
  const query = req.query.q; // Ensure correct parameter key
  
  // Log the query to see if it is being passed correctly
  console.log('Query: ', query);  // Log the query value from the URL

  if (!query) {
    return res.status(400).json({ message: 'Query parameter is required' });
  }

  // Get eBay access token if not available or expired
  if (!accessToken || isAccessTokenExpired()) {
    await getEbayAccessToken();
  }

  // Fetch listings from eBay
  const ebayListings = await fetchEbayListings(query);

  // Send the results as a JSON response
  res.json(ebayListings);
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
